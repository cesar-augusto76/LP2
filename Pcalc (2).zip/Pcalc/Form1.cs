using System.Diagnostics.Eventing.Reader;
using System.Reflection.Metadata.Ecma335;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Num1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(Num1.Text, out numero1))
            {
                errorProvider1.SetError(Num1, "N�mero 1 � inv�lido!");
                Num1.Focus();
            }
            else
                errorProvider1.SetError(Num1, "");
        }

        private void Num2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(Num2, "");
                numero2 = Convert.ToDouble(Num2.Text);
            }
            catch
            {
                errorProvider2.SetError(Num2, "O n�mero 2 � inv�lido!");
                Num2.Focus();
            }

        }

        private void Add_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            Result.Text = resultado.ToString("N10");

        }

        private void Sub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            Result.Text = resultado.ToString();
        }

        private void Mult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            Result.Text = resultado.ToString();
        }

        private void Div_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("N�o � poss�vel dividir por zero!");

            }
            else
            {
                resultado = numero1 / numero2;
                Result.Text = resultado.ToString();
            }
        }

        private void Clean_Click(object sender, EventArgs e)
        {
            Num1.Clear();
            Num2.Clear();
            Result.Clear();
        }

        private void Out_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voc� deseja sair mesmo? Hein???", "Sa�da", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question)
                == DialogResult.Yes)


         
                Close();
         }
    }
}
