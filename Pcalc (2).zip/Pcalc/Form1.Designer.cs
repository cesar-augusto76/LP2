﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            Num1 = new TextBox();
            Num2 = new TextBox();
            Result = new TextBox();
            Clean = new Button();
            Out = new Button();
            Add = new Button();
            Sub = new Button();
            Mult = new Button();
            Div = new Button();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(46, 33);
            label1.Name = "label1";
            label1.Size = new Size(92, 25);
            label1.TabIndex = 0;
            label1.Text = "Numero 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(46, 103);
            label2.Name = "label2";
            label2.Size = new Size(92, 25);
            label2.TabIndex = 1;
            label2.Text = "Numero 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(46, 182);
            label3.Name = "label3";
            label3.Size = new Size(90, 25);
            label3.TabIndex = 2;
            label3.Text = "Resultado";
            // 
            // Num1
            // 
            Num1.Location = new Point(248, 33);
            Num1.Name = "Num1";
            Num1.Size = new Size(150, 31);
            Num1.TabIndex = 3;
    //        Num1.TextChanged += textBox1_TextChanged;
      //      Num1.Validated += Num1_Validated;
            // 
            // Num2
            // 
            Num2.Location = new Point(248, 103);
            Num2.Name = "Num2";
            Num2.Size = new Size(150, 31);
            Num2.TabIndex = 4;
            Num2.Validated += Num2_Validated;
            // 
            // Result
            // 
            Result.Location = new Point(248, 182);
            Result.Name = "Result";
            Result.Size = new Size(150, 31);
            Result.TabIndex = 5;
            // 
            // Clean
            // 
            Clean.Location = new Point(564, 33);
            Clean.Name = "Clean";
            Clean.Size = new Size(173, 74);
            Clean.TabIndex = 6;
            Clean.Text = "Limpar";
            Clean.UseVisualStyleBackColor = true;
            Clean.Click += Clean_Click;
            // 
            // Out
            // 
            Out.Location = new Point(564, 129);
            Out.Name = "Out";
            Out.Size = new Size(173, 78);
            Out.TabIndex = 7;
            Out.Text = "Sair";
            Out.UseVisualStyleBackColor = true;
            Out.Click += Out_Click;
            // 
            // Add
            // 
            Add.Location = new Point(46, 328);
            Add.Name = "Add";
            Add.Size = new Size(114, 66);
            Add.TabIndex = 8;
            Add.Text = "+";
            Add.UseVisualStyleBackColor = true;
            Add.Click += Add_Click;
            // 
            // Sub
            // 
            Sub.Location = new Point(222, 328);
            Sub.Name = "Sub";
            Sub.Size = new Size(117, 66);
            Sub.TabIndex = 9;
            Sub.Text = "-";
            Sub.UseVisualStyleBackColor = true;
            Sub.Click += Sub_Click;
            // 
            // Mult
            // 
            Mult.Location = new Point(408, 328);
            Mult.Name = "Mult";
            Mult.Size = new Size(122, 66);
            Mult.TabIndex = 10;
            Mult.Text = "*";
            Mult.UseVisualStyleBackColor = true;
            Mult.Click += Mult_Click;
            // 
            // Div
            // 
            Div.Location = new Point(600, 328);
            Div.Name = "Div";
            Div.Size = new Size(121, 66);
            Div.TabIndex = 11;
            Div.Text = "/";
            Div.UseVisualStyleBackColor = true;
            Div.Click += Div_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Div);
            Controls.Add(Mult);
            Controls.Add(Sub);
            Controls.Add(Add);
            Controls.Add(Out);
            Controls.Add(Clean);
            Controls.Add(Result);
            Controls.Add(Num2);
            Controls.Add(Num1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox Num1;
        private TextBox Num2;
        private TextBox Result;
        private Button Clean;
        private Button Out;
        private Button Add;
        private Button Sub;
        private Button Mult;
        private Button Div;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
    }
}
