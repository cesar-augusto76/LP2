namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calc_Click(object sender, EventArgs e)
        {
            try
            {
                double peso = Convert.ToDouble(Pes.Text);
                double altura = Convert.ToDouble(Altu.Text);
                if (altura <= 0)
                {
                    MessageBox.Show("A altura deve ser maior que 0", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                double imc = peso / (altura * altura);
                string classificacao = "";

                if (imc < 18.5)
                {
                    classificacao = "Magreza, obesidade grau 0";
                }
                if (imc <= 24.9)
                {
                    classificacao = "Normal, obesidade grau I";
                }
                if (imc <= 29.9)
                {
                    classificacao = "Sobrepeso, obesidade grau I";
                }
                if (imc <= 39.9)
                {
                    classificacao = "Obesidade grau II";
                }
                else
                    classificacao = "Obesidade grave, grau III";

                recebIMC.Text = $"IMC: {imc:F2} - {classificacao}";
            }
            catch
            {
                MessageBox.Show("Insira valores v�lidos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Clean_Click(object sender, EventArgs e)
        {
            Pes.Clear();
            Altu.Clear();
            recebIMC.Clear();
            Pes.Focus();
        }

        private void Out_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Alt_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
