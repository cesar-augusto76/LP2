﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Calc = new Button();
            Clean = new Button();
            Out = new Button();
            Peso = new Label();
            Alt = new Label();
            IMC = new Label();
            Pes = new TextBox();
            Altu = new TextBox();
            recebIMC = new TextBox();
            SuspendLayout();
            // 
            // Calc
            // 
            Calc.Location = new Point(77, 274);
            Calc.Name = "Calc";
            Calc.Size = new Size(103, 50);
            Calc.TabIndex = 0;
            Calc.Text = "Calcular";
            Calc.UseVisualStyleBackColor = true;
            Calc.Click += Calc_Click;
            // 
            // Clean
            // 
            Clean.Location = new Point(317, 274);
            Clean.Name = "Clean";
            Clean.Size = new Size(104, 49);
            Clean.TabIndex = 1;
            Clean.Text = "Limpar";
            Clean.UseVisualStyleBackColor = true;
            Clean.Click += Clean_Click;
            // 
            // Out
            // 
            Out.Location = new Point(566, 274);
            Out.Name = "Out";
            Out.Size = new Size(98, 49);
            Out.TabIndex = 2;
            Out.Text = "Sair";
            Out.UseVisualStyleBackColor = true;
            Out.Click += Out_Click;
            // 
            // Peso
            // 
            Peso.AutoSize = true;
            Peso.Location = new Point(36, 30);
            Peso.Name = "Peso";
            Peso.Size = new Size(63, 15);
            Peso.TabIndex = 3;
            Peso.Text = "Peso Atual";
            // 
            // Alt
            // 
            Alt.AutoSize = true;
            Alt.Location = new Point(39, 86);
            Alt.Name = "Alt";
            Alt.Size = new Size(39, 15);
            Alt.TabIndex = 4;
            Alt.Text = "Altura";
            Alt.Click += Alt_Click;
            // 
            // IMC
            // 
            IMC.AutoSize = true;
            IMC.Location = new Point(36, 140);
            IMC.Name = "IMC";
            IMC.Size = new Size(29, 15);
            IMC.TabIndex = 5;
            IMC.Text = "IMC";
            // 
            // Pes
            // 
            Pes.Location = new Point(176, 42);
            Pes.Name = "Pes";
            Pes.Size = new Size(197, 23);
            Pes.TabIndex = 6;
            // 
            // Altu
            // 
            Altu.Location = new Point(176, 86);
            Altu.Name = "Altu";
            Altu.Size = new Size(197, 23);
            Altu.TabIndex = 7;
            // 
            // recebIMC
            // 
            recebIMC.Location = new Point(176, 132);
            recebIMC.Name = "recebIMC";
            recebIMC.Size = new Size(197, 23);
            recebIMC.TabIndex = 8;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(recebIMC);
            Controls.Add(Altu);
            Controls.Add(Pes);
            Controls.Add(IMC);
            Controls.Add(Alt);
            Controls.Add(Peso);
            Controls.Add(Out);
            Controls.Add(Clean);
            Controls.Add(Calc);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Calc;
        private Button Clean;
        private Button Out;
        private Label Peso;
        private Label Alt;
        private Label IMC;
        private TextBox Pes;
        private TextBox Altu;
        private TextBox recebIMC;
    }
}
