using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] NumsInteiros = new int[20];
            string auxiliar = "";
            for (int i = 0; i < NumsInteiros.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite um n�mero: ", "Entrada de dados");
                if (!int.TryParse(auxiliar, out NumsInteiros[i]))
                {
                    MessageBox.Show("Dados inv�lidos!");
                    i--;
                }
            }
            Array.Reverse(NumsInteiros); //Vetor est� sendo invertido
            auxiliar = "";
            auxiliar = String.Join("\n", NumsInteiros);
            MessageBox.Show(auxiliar);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i;
            ArrayList NomesAlunos = new ArrayList();
            NomesAlunos = ["Ana", "Andr�", "Beatriz", "Camila", "Jo�o", "Joana", "Ot�vio", "Marcelo", "Pedro", "Tais"];
            for (i = 0; i < NomesAlunos.Count; i++)
            {
                if (NomesAlunos.Contains("Ot�vio"))
                {
                    NomesAlunos.Remove("Ot�vio");
                    foreach (string s in NomesAlunos)
                    {
                        MessageBox.Show(s);
                    }


                }
            }
        }

        private void Botao3_Click(object sender, EventArgs e)
        {
            double[,] NotasAlunos = new double[20, 3];
            double media = 0;
            int i, j;
            string auxiliar;
            for (i = 0; i < 20; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite 3 notas e ser� calculada a m�dia de cada aluno: ");
                    if (double.TryParse(auxiliar, out NotasAlunos[i, j]))
                    {

                        media += NotasAlunos[i, j] / 3;

                        MessageBox.Show($"A nota do aluno {i + 1} na prova {j + 1}: {NotasAlunos[i, j]}");
                    }
                    else
                    {
                        MessageBox.Show("Insira valores v�lidos!");
                    }

                }
                MessageBox.Show($"A m�dia do aluno {i} �: " + media);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form2>().Count() > 0)
            {
                Application.OpenForms["Form2"].BringToFront();
            }
            else
            {
                Form2 obj1 = new Form2();
                obj1.Show();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3>().Count() > 0)
            {
                Application.OpenForms["Form3"].BringToFront();
            }
            else
            {
                Form3 obj1 = new Form3();
                obj1.Show();
            }
        }
    }
}
