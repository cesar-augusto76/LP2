﻿namespace PMatrizes
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Gab = new Button();
            listBox2 = new ListBox();
            SuspendLayout();
            // 
            // Gab
            // 
            Gab.Location = new Point(307, 75);
            Gab.Name = "Gab";
            Gab.Size = new Size(115, 84);
            Gab.TabIndex = 0;
            Gab.Text = "Gabarito";
            Gab.UseVisualStyleBackColor = true;
            Gab.Click += Gab_Click;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(261, 188);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(264, 94);
            listBox2.TabIndex = 1;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listBox2);
            Controls.Add(Gab);
            Name = "Form3";
            Text = "Form3";
            ResumeLayout(false);
        }

        #endregion

        private Button Gab;
        private ListBox listBox2;
    }
}