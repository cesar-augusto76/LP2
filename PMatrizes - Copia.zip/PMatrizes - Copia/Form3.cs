﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form3 : Form
    {
        private object listBox1 = 0;

        public Form3()
        {
            InitializeComponent();
        }

        private void Gab_Click(object sender, EventArgs e)
        {
            int[] NumeroAlunos = new int[9]; 
            char[] Gabarito = new char[10]; 
            char[] Respostas = { 'A', 'D', 'D', 'E', 'C', 'B', 'D', 'C', 'C', 'B' };

            Gabarito = (char[])Respostas.Clone();

            int i, j;
            string auxiliar;
            char[,] RespostasAlunos = new char[9, 10];

            listBox2.Items.Clear();

            for (i = 0; i < NumeroAlunos.Length; i++)
            { 
                for (j = 0; j < Gabarito.Length; j++)
                {
                    auxiliar = Interaction.InputBox("Insira as suas respostas para as 10 questões");

                    if (!string.IsNullOrEmpty(auxiliar))
                    {
                        RespostasAlunos[i, j] = Char.ToUpper(auxiliar[0]);
                    }

                    listBox2.Items.Add($"Aluno {i + 1}, Questão {j + 1}: marcou '{RespostasAlunos[i, j]}', resposta correta: '{Gabarito[j]}'");
                }

            }
        }
    }
}
