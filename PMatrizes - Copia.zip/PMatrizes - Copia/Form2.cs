﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Execute_Click(object sender, EventArgs e)
        {
            ArrayList NomesPessoas = new ArrayList();
            string nome;
            for (int i = 0; i < 10; i++)
            {
                nome = Interaction.InputBox($"Insira o nome de 10 pessoas:");
                NomesPessoas.Add(nome);
            }

            foreach (string nomePessoa in NomesPessoas)
            {
                string nomeSemEspacos = nomePessoa.Replace(" ", "");

                int tamanho = nomeSemEspacos.Length;
                MessageBox.Show($"O nome \"{nomePessoa}\" tem {tamanho} letras");
            }
                }
            }
            
        }