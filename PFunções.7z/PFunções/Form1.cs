namespace PFunções
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Função sem retorno e sem parâmetros
        void Soma()
        {
            double resultado = 5 + 6;
            MessageBox.Show(resultado.ToString());
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Soma();
        }
        //Com retorno e sem parâmetros
        Double Soma1()
        {
            double resultado = 5 + 6;
            return resultado;
        }

        private void btnSoma1_Click(object sender, EventArgs e)
        {
            double retorno = Soma1();
            MessageBox.Show(retorno.ToString());

        }
        void Soma2(double x, double y)
        {
            x = x * 10;
            double resultado = x + y;
            MessageBox.Show(resultado.ToString());
        }

        private void btnSoma2_Click(object sender, EventArgs e)
        {
            Double numero1 = 5;
            Double numero2 = 6;
            Soma2(numero1, numero2);
            MessageBox.Show(numero1.ToString());
        }
        void Soma3(ref double x, double y)
        {
            x = x * 10;
            y = y + 10;
            double resultado = x + y;
            MessageBox.Show(resultado.ToString());
        }

        private void btnSoma3_Click(object sender, EventArgs e)
        {
            Double numero1 = 5;
            Double numero2 = 6;
            Soma3(ref numero1, numero2);
            MessageBox.Show(numero1.ToString());
            MessageBox.Show(numero2.ToString());
        }
        Double Soma4(Double x, Double y, out Double resultadoDobro)
        {
            resultadoDobro = (x + y) * 2;
            return x + y;
        }

        private void btnSoma4_Click(object sender, EventArgs e)
        {
            double r = 0;
            double numero1 = 6;
            double numero2 = 5;
            MessageBox.Show(Soma4(numero1, numero2, out r).ToString());
            MessageBox.Show(r.ToString());
        }
        double Soma5(double x, double y, double z = 0)
        {
            if (z > 0)
            {
                return (x + y + z) / 3;
            }
            else
            {
                return (x + y) / 2;
            }
        }

        private void btnSoma5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sem o 3o parâmetro: " + Soma5(5, 6));
            MessageBox.Show("Com o 3o parâmetro: " + Soma5(5, 6, 10));
        }

        private void formatacaoDatas_Click(object sender, EventArgs e)
        {
            DateTime data = DateTime.Now;
            MessageBox.Show("Data curta =" + data.ToShortDateString());
            MessageBox.Show ("Hora extensa: " + data.ToLongTimeString());
            MessageBox.Show ("Com formatos" + data.ToString("dd/MM/yyyy"));

            DateTime data2 = Convert.ToDateTime("30/03/2007");

            double dias = data.Subtract(data2).TotalDays;
            MessageBox.Show("A diferença de dias é: " + dias);

            DateTime novaData = data2.AddDays(10);
            MessageBox.Show("Nova data:", novaData.ToString());
        }
    }
}
