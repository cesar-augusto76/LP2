﻿namespace PFunções
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSoma = new Button();
            btnSoma1 = new Button();
            btnSoma2 = new Button();
            btnSoma3 = new Button();
            btnSoma4 = new Button();
            btnSoma5 = new Button();
            formatacaoDatas = new Button();
            SuspendLayout();
            // 
            // btnSoma
            // 
            btnSoma.Location = new Point(27, 100);
            btnSoma.Name = "btnSoma";
            btnSoma.Size = new Size(131, 77);
            btnSoma.TabIndex = 0;
            btnSoma.Text = "Soma";
            btnSoma.UseVisualStyleBackColor = true;
            btnSoma.Click += btnSoma_Click;
            // 
            // btnSoma1
            // 
            btnSoma1.Location = new Point(215, 100);
            btnSoma1.Name = "btnSoma1";
            btnSoma1.Size = new Size(128, 77);
            btnSoma1.TabIndex = 1;
            btnSoma1.Text = "Soma1";
            btnSoma1.UseVisualStyleBackColor = true;
            btnSoma1.Click += btnSoma1_Click;
            // 
            // btnSoma2
            // 
            btnSoma2.Location = new Point(444, 100);
            btnSoma2.Name = "btnSoma2";
            btnSoma2.Size = new Size(133, 77);
            btnSoma2.TabIndex = 2;
            btnSoma2.Text = "Soma2";
            btnSoma2.UseVisualStyleBackColor = true;
            btnSoma2.Click += btnSoma2_Click;
            // 
            // btnSoma3
            // 
            btnSoma3.Location = new Point(625, 100);
            btnSoma3.Name = "btnSoma3";
            btnSoma3.Size = new Size(136, 77);
            btnSoma3.TabIndex = 3;
            btnSoma3.Text = "Soma3";
            btnSoma3.UseVisualStyleBackColor = true;
            btnSoma3.Click += btnSoma3_Click;
            // 
            // btnSoma4
            // 
            btnSoma4.Location = new Point(112, 255);
            btnSoma4.Name = "btnSoma4";
            btnSoma4.Size = new Size(132, 85);
            btnSoma4.TabIndex = 4;
            btnSoma4.Text = "Soma4";
            btnSoma4.UseVisualStyleBackColor = true;
            btnSoma4.Click += btnSoma4_Click;
            // 
            // btnSoma5
            // 
            btnSoma5.Location = new Point(313, 258);
            btnSoma5.Name = "btnSoma5";
            btnSoma5.Size = new Size(143, 85);
            btnSoma5.TabIndex = 5;
            btnSoma5.Text = "Soma 5";
            btnSoma5.UseVisualStyleBackColor = true;
            btnSoma5.Click += btnSoma5_Click;
            // 
            // formatacaoDatas
            // 
            formatacaoDatas.Location = new Point(539, 258);
            formatacaoDatas.Name = "formatacaoDatas";
            formatacaoDatas.Size = new Size(149, 85);
            formatacaoDatas.TabIndex = 6;
            formatacaoDatas.Text = "Formatação datas";
            formatacaoDatas.UseVisualStyleBackColor = true;
            formatacaoDatas.Click += formatacaoDatas_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(formatacaoDatas);
            Controls.Add(btnSoma5);
            Controls.Add(btnSoma4);
            Controls.Add(btnSoma3);
            Controls.Add(btnSoma2);
            Controls.Add(btnSoma1);
            Controls.Add(btnSoma);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnSoma;
        private Button btnSoma1;
        private Button btnSoma2;
        private Button btnSoma3;
        private Button btnSoma4;
        private Button btnSoma5;
        private Button formatacaoDatas;
    }
}
