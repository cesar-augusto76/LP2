﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            ValA = new TextBox();
            ValB = new TextBox();
            ValC = new TextBox();
            Execute = new Button();
            Out = new Button();
            Clean = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(81, 47);
            label1.Name = "label1";
            label1.Size = new Size(94, 25);
            label1.TabIndex = 0;
            label1.Text = "Valor de A";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(81, 120);
            label2.Name = "label2";
            label2.Size = new Size(92, 25);
            label2.TabIndex = 1;
            label2.Text = "Valor de B";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(81, 192);
            label3.Name = "label3";
            label3.Size = new Size(93, 25);
            label3.TabIndex = 2;
            label3.Text = "Valor de C";
            // 
            // ValA
            // 
            ValA.Location = new Point(269, 45);
            ValA.Name = "ValA";
            ValA.Size = new Size(230, 31);
            ValA.TabIndex = 3;
            ValA.Validated += ValA_Validated;
            // 
            // ValB
            // 
            ValB.Location = new Point(270, 120);
            ValB.Name = "ValB";
            ValB.Size = new Size(229, 31);
            ValB.TabIndex = 4;
            ValB.TextChanged += ValB_TextChanged;
            // 
            // ValC
            // 
            ValC.Location = new Point(273, 198);
            ValC.Name = "ValC";
            ValC.Size = new Size(226, 31);
            ValC.TabIndex = 5;
            ValC.TextChanged += ValC_TextChanged;
            // 
            // Execute
            // 
            Execute.Location = new Point(100, 300);
            Execute.Name = "Execute";
            Execute.Size = new Size(157, 80);
            Execute.TabIndex = 6;
            Execute.Text = "Executar";
            Execute.UseVisualStyleBackColor = true;
            Execute.Click += Execute_Click;
            // 
            // Out
            // 
            Out.Location = new Point(557, 300);
            Out.Name = "Out";
            Out.Size = new Size(167, 80);
            Out.TabIndex = 7;
            Out.Text = "Sair";
            Out.UseVisualStyleBackColor = true;
            Out.Click += Out_Click;
            // 
            // Clean
            // 
            Clean.Location = new Point(325, 300);
            Clean.Name = "Clean";
            Clean.Size = new Size(151, 80);
            Clean.TabIndex = 8;
            Clean.Text = "Limpar";
            Clean.UseVisualStyleBackColor = true;
            Clean.Click += Clean_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Clean);
            Controls.Add(Out);
            Controls.Add(Execute);
            Controls.Add(ValC);
            Controls.Add(ValB);
            Controls.Add(ValA);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox ValA;
        private TextBox ValB;
        private TextBox ValC;
        private Button Execute;
        private Button Out;
        private Button Clean;
    }
}
