namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void ValA_Validated(object sender, EventArgs e)
        {
            try
            {
                LadoA = Convert.ToDouble(ValA.Text);
                LadoB = Convert.ToDouble(ValB.Text);
                LadoC = Convert.ToDouble(ValC.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Insira valores v�lidos");
            }

        }

        private void ValB_TextChanged(object sender, EventArgs e)
        {
            if (Double.TryParse(ValB.Text, out double result))
            {
                LadoB = result;
            }
            
        }

        private void ValC_TextChanged(object sender, EventArgs e)
        {
            if (Double.TryParse(ValC.Text, out double result))
            {
                LadoC = result;
            }
        }


        private void Execute_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(ValA.Text, out LadoA) && Double.TryParse(ValB.Text, out LadoB) && Double.TryParse(ValC.Text, out LadoC))
                {


                if (LadoA == LadoB && LadoA == LadoC)
                {
                    MessageBox.Show("� um tri�ngulo equil�tero!");
                }
                else if
                    (LadoA == LadoB || LadoA == LadoC || LadoB == LadoC)
                {
                    MessageBox.Show("� um tri�ngulo is�sceles!");
                }
                else
                {
                    MessageBox.Show("� um tri�ngulo escaleno!");
                }
            }
        }

        private void Clean_Click(object sender, EventArgs e)
        {
            ValA.Clear();
            ValB.Clear();
            ValC.Clear();
        }

        private void Out_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
