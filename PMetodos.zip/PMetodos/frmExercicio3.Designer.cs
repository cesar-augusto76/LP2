﻿namespace PMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            Remov12 = new Button();
            Invert1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(91, 40);
            label1.Name = "label1";
            label1.Size = new Size(82, 25);
            label1.TabIndex = 0;
            label1.Text = "Palavra 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(91, 123);
            label2.Name = "label2";
            label2.Size = new Size(82, 25);
            label2.TabIndex = 1;
            label2.Text = "Palavra 2";
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(272, 47);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(150, 31);
            txtPalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(315, 123);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(150, 31);
            txtPalavra2.TabIndex = 3;
            // 
            // Remov12
            // 
            Remov12.Location = new Point(106, 261);
            Remov12.Name = "Remov12";
            Remov12.Size = new Size(196, 80);
            Remov12.TabIndex = 4;
            Remov12.Text = "Remover o 1 do 2";
            Remov12.UseVisualStyleBackColor = true;
            Remov12.Click += Remov12_Click;
            // 
            // Invert1
            // 
            Invert1.Location = new Point(410, 270);
            Invert1.Name = "Invert1";
            Invert1.Size = new Size(152, 62);
            Invert1.TabIndex = 5;
            Invert1.Text = "Inverter o 1";
            Invert1.UseVisualStyleBackColor = true;
            Invert1.Click += Invert1_Click;
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Invert1);
            Controls.Add(Remov12);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Button Remov12;
        private Button Invert1;
    }
}