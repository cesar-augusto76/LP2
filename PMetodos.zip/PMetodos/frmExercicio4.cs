﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void Conta_Click(object sender, EventArgs e)
        {
            int comprimento = rchtxtFrase.Text.Length;
            int cont = 0;
            int contaNum = 0;
            while (cont < comprimento)
            {
                if (Char.IsNumber(rchtxtFrase.Text[cont]))
                {
                    contaNum++;
                }
                cont++;
            }
            MessageBox.Show($"O texto tem {contaNum} números");
        }

        private void Posicao1caract_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do 1 caracter em branco é: {i + 1}");
                    break;
                }
            }
        }

        private void ContaLetras_Click(object sender, EventArgs e)
        {
            int contaLetra=0;
            foreach (var c in rchtxtFrase.Text)
            {
                if (Char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"O texto tem {contaLetra} letras");
        }
    }
}
