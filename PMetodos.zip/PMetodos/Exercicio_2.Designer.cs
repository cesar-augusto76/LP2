﻿namespace PMetodos
{
    partial class Exercicio_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPalavra1 = new Label();
            lblPalavra2 = new Label();
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            Compara = new Button();
            Inserir = new Button();
            InserirMeio = new Button();
            SuspendLayout();
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(108, 50);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(82, 25);
            lblPalavra1.TabIndex = 0;
            lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(108, 123);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(82, 25);
            lblPalavra2.TabIndex = 1;
            lblPalavra2.Text = "Palavra 2";
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(262, 35);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(150, 31);
            txtPalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(270, 123);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(150, 31);
            txtPalavra2.TabIndex = 3;
            // 
            // Compara
            // 
            Compara.Location = new Point(82, 293);
            Compara.Name = "Compara";
            Compara.Size = new Size(158, 75);
            Compara.TabIndex = 4;
            Compara.Text = "Comparar iguais";
            Compara.UseVisualStyleBackColor = true;
            // 
            // Inserir
            // 
            Inserir.Location = new Point(324, 293);
            Inserir.Name = "Inserir";
            Inserir.Size = new Size(147, 75);
            Inserir.TabIndex = 5;
            Inserir.Text = "Inserir 1 e 2";
            Inserir.UseVisualStyleBackColor = true;
            // 
            // InserirMeio
            // 
            InserirMeio.Location = new Point(582, 284);
            InserirMeio.Name = "InserirMeio";
            InserirMeio.Size = new Size(146, 84);
            InserirMeio.TabIndex = 6;
            InserirMeio.Text = "Inserir ** no meio do 1";
            InserirMeio.UseVisualStyleBackColor = true;
            // 
            // Exercicio_2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(InserirMeio);
            Controls.Add(Inserir);
            Controls.Add(Compara);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Name = "Exercicio_2";
            Text = "Exercicio_2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPalavra1;
        private Label lblPalavra2;
        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Button Compara;
        private Button Inserir;
        private Button InserirMeio;
    }
}