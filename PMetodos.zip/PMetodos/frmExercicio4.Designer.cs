﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            Conta = new Button();
            Posicao1caract = new Button();
            ContaLetras = new Button();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(101, 12);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(558, 305);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // Conta
            // 
            Conta.Location = new Point(49, 323);
            Conta.Name = "Conta";
            Conta.Size = new Size(203, 67);
            Conta.TabIndex = 1;
            Conta.Text = "Conta Numeros";
            Conta.UseVisualStyleBackColor = true;
            Conta.Click += Conta_Click;
            // 
            // Posicao1caract
            // 
            Posicao1caract.Location = new Point(285, 323);
            Posicao1caract.Name = "Posicao1caract";
            Posicao1caract.Size = new Size(169, 67);
            Posicao1caract.TabIndex = 2;
            Posicao1caract.Text = "Posição 1 caracter branco";
            Posicao1caract.UseVisualStyleBackColor = true;
            Posicao1caract.Click += Posicao1caract_Click;
            // 
            // ContaLetras
            // 
            ContaLetras.Location = new Point(494, 323);
            ContaLetras.Name = "ContaLetras";
            ContaLetras.Size = new Size(203, 67);
            ContaLetras.TabIndex = 3;
            ContaLetras.Text = "Conta Letras";
            ContaLetras.UseVisualStyleBackColor = true;
            ContaLetras.Click += ContaLetras_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(ContaLetras);
            Controls.Add(Posicao1caract);
            Controls.Add(Conta);
            Controls.Add(rchtxtFrase);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button Conta;
        private Button Posicao1caract;
        private Button ContaLetras;
    }
}