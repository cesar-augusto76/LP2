namespace PMetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Menu Copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Menu colar");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {


            if (Application.OpenForms.OfType<Exercicio_2>().Count() > 0)
            {
                Application.OpenForms["Exercicio2"].BringToFront();
            }
            else
            {
                Exercicio_2 objForm2 = new Exercicio_2();
                objForm2.MdiParent = this;
                objForm2.WindowState = FormWindowState.Maximized;
                objForm2.Show();
            }
            {

            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
