namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || raio <= 0)
            {
                MessageBox.Show("Raio inv�lido!");
            }
            else
            {
                if (raio < 0)
                {
                    MessageBox.Show("O raio deve ser maior que zero!");
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura inv�lida, faz melhor ai");
            }
            else
            {
                if (altura < 0)
                {
                    MessageBox.Show("A altura deve ser maior que zero!");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || (raio <= 0))
            {
                MessageBox.Show("Raio inv�lido!");
                txtRaio.Focus();
            }
            else if (!Double.TryParse(txtAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura inv�lida");
                txtAltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = String.Empty;
            txtVolume.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
